// app/child/[id].tsx
// v2 — Child hub. Each child has their own SOS experience.
// Journal identity: pastel gradient, frosted glass, rose accents.
// Replaces the old standalone now.tsx — SOS lives here, scoped per child.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { router, useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';

import { useAuth } from '../../src/context/AuthContext';
import { useChildProfile } from '../../src/context/ChildProfileContext';
import { getParentingScript, CrisisDetectedError, RateLimitError } from '../../src/lib/api';
import { detectCrisis } from '../../src/hooks/useCrisisMode';
import { loadSavedScripts, type SavedScriptRow } from '../../src/lib/loadSavedScripts';
import { incrementScriptCount } from '../../src/utils/profileNudge';
import { useSubscription } from '../../src/hooks/useSubscription';
import { getTone, setTone, type Tone, TONE_DEFAULT } from '../../src/utils/tone';
import { PaywallSheet } from '../../src/components/ui/PaywallSheet';
import { colors as C, fonts as F } from '../../src/theme';


// ═══════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════

const INTENSITY_OPTIONS = [
  { level: 1, label: 'Mild',     color: C.sage },
  { level: 2, label: 'Building', color: '#5778A3' },
  { level: 3, label: 'Hard',     color: '#F79566' },
  { level: 4, label: 'Intense',  color: C.sos },
] as const;

// Tone selector — Sturdy+ only. Free users default to Gentle (per
// Master Blueprint); Soft + Direct are locked behind PaywallSheet.
const TONE_OPTIONS: Array<{ key: Tone; label: string; sub: string; premium: boolean }> = [
  { key: 'soft',   label: 'Soft',   sub: 'Warm, spacious',  premium: true },
  { key: 'gentle', label: 'Gentle', sub: 'Calm but clear',  premium: false },
  { key: 'direct', label: 'Direct', sub: 'Short, firm',     premium: true },
];

const TIMEOUT_MS = 20 * 60 * 1000; // 20 min idle → sign out

// ═══════════════════════════════════════════════
// MODE COPY
// The hub serves all 4 outcome modes (SOS / Reconnect / Understand /
// Conversation). The mode comes from the URL `mode` param (set when the
// parent taps an outcome card on Home). All four backend prompts return
// the same R/C/G shape — we just adapt the input copy + intensity gating
// so the parent knows what they're getting.
// Intensity only matters for SOS — buildPrompt ignores it for the others.
// ═══════════════════════════════════════════════

type HubMode = 'sos' | 'reconnect' | 'understand' | 'conversation';

const MODE_COPY: Record<HubMode, {
  placeholder: (name: string) => string;
  hint:        string;
  cta:         string;
  ctaLoading:  string;
  showIntensity: boolean;
}> = {
  sos: {
    placeholder: (n) => `What's happening with ${n} right now?`,
    hint:        'A simple snapshot is enough.',
    cta:         'Get Script',
    ctaLoading:  'Getting script…',
    showIntensity: true,
  },
  reconnect: {
    placeholder: (n) => `What needs repair with ${n}?`,
    hint:        'A few sentences about what just happened.',
    cta:         'Find the words',
    ctaLoading:  'Finding the words…',
    showIntensity: false,
  },
  understand: {
    placeholder: (n) => `What are you trying to understand about ${n}?`,
    hint:        'Describe the pattern or behaviour.',
    cta:         'Help me see it',
    ctaLoading:  'Reading the pattern…',
    showIntensity: false,
  },
  conversation: {
    placeholder: (n) => `What conversation are you preparing with ${n}?`,
    hint:        'Tell Sturdy the topic and what makes it hard.',
    cta:         'Plan it with me',
    ctaLoading:  'Planning…',
    showIntensity: false,
  },
};

function isHubMode(v: unknown): v is HubMode {
  return v === 'sos' || v === 'reconnect' || v === 'understand' || v === 'conversation';
}


// ═══════════════════════════════════════════════
// SCREEN
// ═══════════════════════════════════════════════

export default function ChildHubScreen() {
  const navigation = useRouter();
  const params = useLocalSearchParams<{ id?: string; mode?: string }>();
  const { session, signOut } = useAuth();
  const { children, activeChild, setActiveChild } = useChildProfile() as any;

  // ─── Mode (defaults to 'sos' if param absent or invalid) ───
  const mode: HubMode = isHubMode(params.mode) ? params.mode : 'sos';
  const copy = MODE_COPY[mode];

  // ─── Resolve the child from the URL id ───
  const child = useMemo(() => {
    if (!params.id || !Array.isArray(children)) return null;
    return children.find((c: any) => c?.id === params.id) ?? null;
  }, [params.id, children]);

  // ─── Keep activeChild in sync with the URL ───
  useEffect(() => {
    if (child && child.id !== activeChild?.id) {
      setActiveChild(child);
    }
  }, [child, activeChild, setActiveChild]);

  // ─── If child not found (stale URL, deleted child), bounce home ───
  useEffect(() => {
    if (Array.isArray(children) && children.length > 0 && !child && params.id) {
      router.replace('/(tabs)');
    }
  }, [children, child, params.id]);

  // ─── State: input ───
  const [situation, setSituation]       = useState('');
  const [intensity, setIntensity]       = useState<number | null>(null);
  const [loading, setLoading]           = useState(false);
  const [error, setError]               = useState('');
  const [crisisFlag, setCrisisFlag]     = useState(false);
  const [inputFocused, setInputFocused] = useState(false);

  // ─── Tone (Sturdy+) ───
  const { isPremium } = useSubscription();
  const [tone, setToneState]            = useState<Tone>(TONE_DEFAULT);
  const [paywallFor, setPaywallFor]     = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    getTone().then((t) => { if (!cancelled) setToneState(t); });
    return () => { cancelled = true; };
  }, []);

  const handleSelectTone = (next: Tone, premium: boolean) => {
    Haptics.selectionAsync();
    if (premium && !isPremium) {
      setPaywallFor(`${next.charAt(0).toUpperCase() + next.slice(1)} tone`);
      return;
    }
    setToneState(next);
    setTone(next).catch(() => { /* no-op */ });
  };

  // ─── State: saved scripts ───
  const [savedScripts, setSavedScripts] = useState<SavedScriptRow[]>([]);
  const [refreshing, setRefreshing]     = useState(false);

  // ─── Refs ───
  const crisisOpacity = useRef(new Animated.Value(0)).current;
  const timeoutRef    = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ─── Session timeout ───
  const resetTimeout = useCallback(() => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (!session) return;
    timeoutRef.current = setTimeout(async () => {
      await signOut();
    }, TIMEOUT_MS);
  }, [session, signOut]);

  useEffect(() => {
    resetTimeout();
    return () => { if (timeoutRef.current) clearTimeout(timeoutRef.current); };
  }, [resetTimeout]);

  // ─── Load saved scripts for this child only ───
  const fetchSaved = useCallback(async () => {
    if (!child?.id) return;
    try {
      const all = await loadSavedScripts();
      setSavedScripts(all.filter((s) => s.child_profile_id === child.id));
    } catch {
      // Non-blocking — silently fall through with empty state
    }
  }, [child?.id]);

  useFocusEffect(
    useCallback(() => {
      fetchSaved();
    }, [fetchSaved])
  );

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    Haptics.selectionAsync();
    await fetchSaved();
    setRefreshing(false);
  }, [fetchSaved]);

  // ─── Input handlers ───
  const handleTextChange = (text: string) => {
    setSituation(text);
    if (error) setError('');
    resetTimeout();

    const crisisCheck = detectCrisis(text);
    if (crisisCheck.isCrisis !== crisisFlag) {
      setCrisisFlag(crisisCheck.isCrisis);
      Animated.timing(crisisOpacity, {
        toValue: crisisCheck.isCrisis ? 1 : 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  };

  const handleSelectIntensity = (level: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setIntensity(intensity === level ? null : level);
    resetTimeout();
  };

  const handleGetScript = async () => {
    const msg = situation.trim();
    if (!msg || !child) return;

    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setError('');
    setLoading(true);
    resetTimeout();

    try {
      const script = await getParentingScript({
        childName: child.name || 'My child',
        childAge:  child.childAge ?? 4,
        message:   msg,
        userId:    session?.user?.id,
        // Intensity is only meaningful for SOS — buildPrompt ignores it
        // for the other modes anyway, but keep the request body clean.
        intensity: mode === 'sos' ? intensity : null,
        mode,
        // Tone preference — sent forward-compat. Free users always send
        // Gentle (the locked default); premium users send their pick.
        // Backend will use this once buildPrompt accepts a tone block.
        tone: isPremium ? tone : 'gentle',
      } as any);

      // Bump per-child script counter — feeds the "after 3+ interactions"
      // profile nudge on the result screen. Fire-and-forget; failures
      // never block the navigation.
      incrementScriptCount(child.id).catch(() => { /* no-op */ });

      navigation.push({
        pathname: '/result',
        params: {
          childId: child.id,
          situationSummary:   script.situation_summary,
          regulateAction:     script.regulate.parent_action,
          regulateScript:     script.regulate.script,
          regulateCoaching:   script.regulate.coaching ?? '',
          regulateStrategies: JSON.stringify(script.regulate.strategies ?? []),
          connectAction:      script.connect.parent_action,
          connectScript:      script.connect.script,
          connectCoaching:    script.connect.coaching ?? '',
          connectStrategies:  JSON.stringify(script.connect.strategies ?? []),
          guideAction:        script.guide.parent_action,
          guideScript:        script.guide.script,
          guideCoaching:      script.guide.coaching ?? '',
          guideStrategies:    JSON.stringify(script.guide.strategies ?? []),
          avoid:              JSON.stringify(script.avoid),
          childMessage:       msg,
          mode,
        },
      });

      // Clear local state so coming back to hub is fresh
      setSituation('');
      setIntensity(null);
    } catch (err) {
      if (err instanceof CrisisDetectedError) {
        router.push({
          pathname: '/crisis',
          params: { crisisType: err.crisisType, riskLevel: err.riskLevel },
        });
        return;
      }
      if (err instanceof RateLimitError) {
        setError(err.message);
        return;
      }
      setError("Couldn't get a script right now. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleUnsafe = () => {
    router.push({
      pathname: '/crisis',
      params: { crisisType: 'manual', riskLevel: 'ELEVATED_RISK' },
    });
  };

  const handleBack = () => {
    Haptics.selectionAsync();
    router.back();
  };

  // ─── Helpers ───
  const initial = (child?.name?.trim()?.[0] ?? '?').toUpperCase();
  const canSubmit = situation.trim().length > 0 && !!child;
  const hasMultipleChildren = Array.isArray(children) && children.length > 1;

  const formatDate = (iso: string): string => {
    const d = new Date(iso);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const days = Math.floor(diff / 86400000);
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  // ─── Background — single C-2 gradient ───
  const Background = () => (
    <LinearGradient
      colors={[
        C.gradientTop,
        C.gradientMid1,
        C.gradientMid2,
        C.gradientMid3,
        C.gradientMid4,
        C.gradientBottom,
      ]}
      locations={[0, 0.14, 0.28, 0.42, 0.58, 1]}
      style={StyleSheet.absoluteFill}
    />
  );

  // ─── Loading gate (child profile not yet resolved) ───
  if (!child) {
    return (
      <View style={s.root}>
        <StatusBar style="light" />
        <Background />
      </View>
    );
  }

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <Background />

      <SafeAreaView style={s.safe} edges={['top']}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={{ flex: 1 }}
        >
          <ScrollView
            contentContainerStyle={s.scroll}
            keyboardDismissMode="interactive"
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            onScrollBeginDrag={resetTimeout}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={handleRefresh}
                tintColor={C.amber}
              />
            }
          >
            {/* ─── Top bar ─── */}
            {hasMultipleChildren ? (
              <View style={s.topBar}>
                <Pressable onPress={handleBack} hitSlop={12} style={s.backBtn}>
                  <Text style={s.backText}>← Back</Text>
                </Pressable>
              </View>
            ) : <View style={{ height: 8 }} />}

            {/* ─── Child identity ─── */}
            <View style={s.identityWrap}>
              <View style={s.avatar}>
                <Text style={s.avatarText}>{initial}</Text>
              </View>
              <Text style={s.childName}>{child.name}</Text>
              <Text style={s.childAge}>Age {child.childAge}</Text>
            </View>

            {/* ─── Message input ─── */}
            <View style={[s.textareaCard, inputFocused && s.textareaFocused]}>
              <TextInput
                multiline
                numberOfLines={5}
                placeholder={copy.placeholder(child.name ?? 'them')}
                placeholderTextColor={C.textMuted}
                value={situation}
                onChangeText={handleTextChange}
                onFocus={() => setInputFocused(true)}
                onBlur={() => setInputFocused(false)}
                style={s.textarea}
                textAlignVertical="top"
              />
              <Text style={s.textareaHint}>{copy.hint}</Text>

              {/* Inline crisis banner */}
              <Animated.View style={[s.crisisBanner, { opacity: crisisOpacity }]}>
                <Pressable onPress={handleUnsafe} style={s.crisisBannerInner}>
                  <Text style={s.crisisIcon}>⚠️</Text>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={s.crisisTitle}>This sounds serious</Text>
                    <Text style={s.crisisSub}>Tap here if you need immediate help →</Text>
                  </View>
                </Pressable>
              </Animated.View>
            </View>

            {/* ─── Tone selector ─── */}
            {/* Sturdy+ feature. Free users see all 3 chips; tapping a
                locked one (Soft/Direct) opens the PaywallSheet. */}
            <View style={s.toneSection}>
              <View style={s.toneHeader}>
                <Text style={s.toneLabel}>Tone</Text>
                {!isPremium ? <Text style={s.tonePremiumPill}>Sturdy+</Text> : null}
              </View>
              <View style={s.toneRow}>
                {TONE_OPTIONS.map((opt) => {
                  const sel = tone === opt.key;
                  const locked = opt.premium && !isPremium;
                  return (
                    <Pressable
                      key={opt.key}
                      onPress={() => handleSelectTone(opt.key, opt.premium)}
                      style={({ pressed }) => [
                        s.tonePill,
                        sel && s.tonePillSelected,
                        pressed && { opacity: 0.85 },
                      ]}
                      accessibilityRole="button"
                      accessibilityState={{ selected: sel, disabled: locked }}
                    >
                      <View style={s.toneTopRow}>
                        <Text style={[s.tonePillLabel, sel && s.tonePillLabelSelected]}>{opt.label}</Text>
                        {locked ? <Text style={s.toneLockIcon}>🔒</Text> : null}
                      </View>
                      <Text style={s.tonePillSub}>{opt.sub}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>

            {/* ─── Intensity (SOS mode only) ─── */}
            {copy.showIntensity ? (
              <View style={s.intensitySection}>
                <View style={s.intensityHeader}>
                  <Text style={s.intensityLabel}>How intense?</Text>
                  <Text style={s.intensityOpt}>optional</Text>
                </View>
                <View style={s.intensityRow}>
                  {INTENSITY_OPTIONS.map((opt) => {
                    const sel = intensity === opt.level;
                    return (
                      <Pressable
                        key={opt.level}
                        onPress={() => handleSelectIntensity(opt.level)}
                        style={({ pressed }) => [
                          s.intensityPill,
                          sel && { backgroundColor: `${opt.color}18`, borderColor: `${opt.color}45` },
                          pressed && { opacity: 0.8 },
                        ]}
                      >
                        <Text style={[s.intensityPillText, sel && { color: opt.color }]}>
                          {opt.label}
                        </Text>
                      </Pressable>
                    );
                  })}
                </View>
              </View>
            ) : null}

            {error ? <Text style={s.errorText}>{error}</Text> : null}

            {/* ─── CTA ─── */}
            <Pressable
              onPress={handleGetScript}
              disabled={!canSubmit || loading}
              style={({ pressed }) => [
                pressed && canSubmit && !loading && { opacity: 0.9, transform: [{ scale: 0.98 }] },
              ]}
            >
              {(!canSubmit || loading) ? (
                <View style={[s.ctaBtn, s.ctaBtnDisabled]}>
                  <Text style={[s.ctaLabel, { color: C.disabledText }]}>
                    {loading ? copy.ctaLoading : copy.cta}
                  </Text>
                </View>
              ) : (
                <LinearGradient
                  colors={[C.amber, C.amberMid]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={s.ctaBtn}
                >
                  <Text style={s.ctaLabel}>{copy.cta}</Text>
                </LinearGradient>
              )}
            </Pressable>

            {/* ─── Emergency link ─── */}
            <Pressable onPress={handleUnsafe} style={s.emergencyBtn}>
              <Text style={s.emergencyText}>
                This feels like an emergency → Get help now
              </Text>
            </Pressable>

            {/* ─── Saved scripts section ─── */}
            {savedScripts.length > 0 ? (
              <View style={s.savedSection}>
                <View style={s.sectionHeader}>
                  <Text style={s.sectionTitle}>Saved for {child.name}</Text>
                  <Pressable onPress={() => router.push('/saved')} hitSlop={10}>
                    <Text style={s.sectionLink}>See all →</Text>
                  </Pressable>
                </View>

                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={s.savedScroll}
                >
                  {savedScripts.slice(0, 5).map((item) => (
                    <Pressable
                      key={item.id}
                      onPress={() => router.push('/saved')}
                      style={({ pressed }) => [
                        s.savedCard,
                        pressed && { opacity: 0.92, transform: [{ scale: 0.99 }] },
                      ]}
                    >
                      <Text style={s.savedDate}>{formatDate(item.created_at)}</Text>
                      <Text style={s.savedTitle} numberOfLines={2}>
                        {item.title || 'Saved script'}
                      </Text>
                      {item.structured?.regulate?.script ? (
                        <Text style={s.savedPreview} numberOfLines={2}>
                          "{item.structured.regulate.script}"
                        </Text>
                      ) : null}
                    </Pressable>
                  ))}
                </ScrollView>
              </View>
            ) : null}

            {/* ─── Profile link (replaces static placeholder) ─── */}
            {/* Doubles as the discoverable entry to the Your Child profile
                screen (Feature 2) — patterns, what works, weekly insight. */}
            <Pressable
              onPress={() => router.push(`/child-profile/${child.id}` as any)}
              style={({ pressed }) => [
                s.insightsSection,
                pressed && { opacity: 0.92, transform: [{ scale: 0.99 }] },
              ]}
              accessibilityRole="button"
              accessibilityLabel={`Open ${child.name}'s profile`}
            >
              <View style={s.insightsRow}>
                <View style={{ flex: 1, gap: 4 }}>
                  <Text style={s.insightsTitle}>{child.name}'s profile</Text>
                  <Text style={s.insightsBody}>
                    Triggers, what works, and what Sturdy is noticing about {child.name}.
                  </Text>
                </View>
                <Text style={s.insightsArrow}>→</Text>
              </View>
            </Pressable>

            {/* ─── Edit profile link ─── */}
            <Pressable
              onPress={() => router.push(`/child/${child.id}?edit=1` as any)}
              style={s.editBtn}
            >
              <Text style={s.editText}>Edit {child.name}'s profile</Text>
            </Pressable>

            <View style={{ height: 40 }} />
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>

      <PaywallSheet
        visible={paywallFor !== null}
        onClose={() => setPaywallFor(null)}
        feature={paywallFor ?? ''}
      />
    </View>
  );
}


// ═══════════════════════════════════════════════
// STYLES
// ═══════════════════════════════════════════════

const card = {
  backgroundColor: C.surface,
  borderWidth:     1,
  borderColor:     C.border,
  borderTopWidth:  1,
  borderTopColor:  C.borderHi,
  borderRadius:    18,
  shadowColor:     '#000000',
  shadowOffset:    { width: 0, height: 6 },
  shadowOpacity:   0.35,
  shadowRadius:    20,
  elevation:       4,
} as const;

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.background },
  safe: { flex: 1 },
  scroll: { paddingHorizontal: 24, paddingBottom: 20, gap: 22 },

  // Top bar
  topBar:   { flexDirection: 'row', alignItems: 'center', paddingTop: 4, paddingBottom: 4 },
  backBtn:  { paddingVertical: 6 },
  backText: { fontFamily: F.bodyMedium, fontSize: 15, color: C.textSecondary },

  // Identity (sits on warm parchment top zone)
  identityWrap: { alignItems: 'center', gap: 10, marginTop: 8 },
  avatar: {
    width:          88,
    height:         88,
    borderRadius:   44,
    backgroundColor: C.amber,
    alignItems:     'center',
    justifyContent: 'center',
    shadowColor:    C.amber,
    shadowOpacity:  0.35,
    shadowRadius:   20,
    shadowOffset:   { width: 0, height: 6 },
    elevation:      4,
  },
  avatarText: { fontFamily: F.heading, fontSize: 36, color: '#FFFFFF', letterSpacing: -0.5 },
  childName:  { fontFamily: F.heading, fontSize: 28, color: C.text, letterSpacing: -0.3, marginTop: 4 },
  childAge:   { fontFamily: F.body, fontSize: 14, color: C.textSecondary },

  // Textarea
  textareaCard: {
    backgroundColor: C.inputBg,
    borderWidth:     1,
    borderColor:     C.inputBorder,
    borderTopWidth:  1,
    borderTopColor:  C.inputHighlight,
    borderRadius:    18,
    overflow:        'hidden',
  },
  textareaFocused: { borderColor: C.borderFocus },
  textarea: {
    padding:    16,
    fontFamily: F.body,
    fontSize:   16,
    color:      C.text,
    lineHeight: 24,
    minHeight:  130,
  },
  textareaHint: {
    fontFamily:        F.body,
    fontSize:          12,
    color:             C.textMuted,
    fontStyle:         'italic',
    paddingHorizontal: 16,
    paddingBottom:     12,
  },

  // Crisis banner
  crisisBanner: {
    borderTopWidth:  1,
    borderTopColor:  'rgba(232,116,97,0.30)',
    backgroundColor: C.sosLight,
  },
  crisisBannerInner: {
    flexDirection:     'row',
    alignItems:        'center',
    gap:               10,
    padding:           12,
    paddingHorizontal: 16,
  },
  crisisIcon:  { fontSize: 16 },
  crisisTitle: { fontFamily: F.bodySemi, fontSize: 13, color: C.sos },
  crisisSub:   { fontFamily: F.body,     fontSize: 11, color: C.textSecondary },

  // Intensity
  intensitySection: { gap: 10 },
  intensityHeader:  { flexDirection: 'row', alignItems: 'center', gap: 8 },
  intensityLabel:   { fontFamily: F.bodyMedium, fontSize: 14, color: C.text },
  intensityOpt:     { fontFamily: F.body, fontSize: 12, color: C.textMuted, fontStyle: 'italic' },
  intensityRow:     { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  intensityPill: {
    flex:              1,
    minWidth:          60,
    paddingVertical:   10,
    paddingHorizontal: 8,
    borderRadius:      12,
    backgroundColor:   C.surface,
    borderWidth:       1,
    borderColor:       C.border,
    borderTopWidth:    1,
    borderTopColor:    C.borderHi,
    alignItems:        'center',
    justifyContent:    'center',
  },
  intensityPillText: { fontFamily: F.bodyMedium, fontSize: 12, color: C.textSecondary },

  // Error
  errorText: { fontFamily: F.body, fontSize: 14, color: C.sos, textAlign: 'center' },

  // CTA
  ctaBtn: {
    minHeight:      56,
    borderRadius:   18,
    alignItems:     'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    shadowColor:    C.amber,
    shadowOffset:   { width: 0, height: 6 },
    shadowOpacity:  0.35,
    shadowRadius:   20,
    elevation:      4,
  },
  ctaBtnDisabled: { backgroundColor: C.disabled, shadowOpacity: 0, elevation: 0 },
  ctaLabel:       { fontFamily: F.subheading, fontSize: 17, color: '#FFFFFF', letterSpacing: 0.3 },

  emergencyBtn:  { alignSelf: 'center', paddingVertical: 6 },
  emergencyText: { fontFamily: F.body, fontSize: 12, color: C.sos, textDecorationLine: 'underline' },

  // Saved scripts
  savedSection: { gap: 10, marginTop: 8 },
  sectionHeader: {
    flexDirection:  'row',
    alignItems:     'baseline',
    justifyContent: 'space-between',
  },
  sectionTitle: { fontFamily: F.bodySemi, fontSize: 15, color: C.text },
  sectionLink:  { fontFamily: F.bodyMedium, fontSize: 13, color: C.amberLight },

  savedScroll: { gap: 10, paddingRight: 4 },
  savedCard: {
    ...card,
    width:        220,
    padding:      14,
    gap:          6,
    borderRadius: 16,
  },
  savedDate:    { fontFamily: F.body, fontSize: 11, color: C.textMuted },
  savedTitle:   { fontFamily: F.bodySemi, fontSize: 14, color: C.text, lineHeight: 20 },
  savedPreview: { fontFamily: F.scriptItalic, fontSize: 13, color: C.textSecondary, lineHeight: 19 },

  // Tone selector
  toneSection: { gap: 8 },
  toneHeader:  { flexDirection: 'row', alignItems: 'center', gap: 8 },
  toneLabel:   { fontFamily: F.bodyMedium, fontSize: 13, color: C.text, letterSpacing: 0.3 },
  tonePremiumPill: {
    fontFamily:        F.label,
    fontSize:          9,
    letterSpacing:     0.8,
    color:             C.amber,
    backgroundColor:   C.amberBadge,
    paddingHorizontal: 8,
    paddingVertical:   3,
    borderRadius:      999,
    overflow:          'hidden',
  },
  toneRow: { flexDirection: 'row', gap: 8 },
  tonePill: {
    flex:            1,
    padding:         12,
    gap:             4,
    borderRadius:    14,
    backgroundColor: C.surface,
    borderColor:     C.border,
    borderWidth:     1,
    borderTopWidth:  1,
    borderTopColor:  C.borderHi,
  },
  tonePillSelected: {
    backgroundColor: 'rgba(200,136,58,0.08)',
    borderColor:     C.amber,
  },
  toneTopRow:            { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  tonePillLabel:         { fontFamily: F.bodySemi, fontSize: 14, color: C.text },
  tonePillLabelSelected: { color: C.amber },
  tonePillSub:           { fontFamily: F.body, fontSize: 11, color: C.textSecondary },
  toneLockIcon:          { fontSize: 11, color: C.amber },

  // Insights / profile-link card
  insightsSection: {
    ...card,
    padding:         16,
    gap:             6,
    borderRadius:    16,
    backgroundColor: C.sageLight,
    borderColor:     'rgba(138,160,96,0.30)',
  },
  insightsRow:   { flexDirection: 'row', alignItems: 'center', gap: 12 },
  insightsTitle: { fontFamily: F.bodySemi, fontSize: 14, color: C.sage },
  insightsBody:  { fontFamily: F.body, fontSize: 13, color: C.textSecondary, lineHeight: 20 },
  insightsArrow: { fontFamily: F.bodySemi, fontSize: 18, color: C.sage },

  // Edit
  editBtn:  { alignSelf: 'center', paddingVertical: 8 },
  editText: {
    fontFamily:         F.bodyMedium,
    fontSize:           13,
    color:              C.textMuted,
    textDecorationLine: 'underline',
  },
});
