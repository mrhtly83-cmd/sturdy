// app/result.tsx
// v9 — Journal identity: pastel gradient, frosted glass, rose accents
// All logic preserved: progressive disclosure, voice, feedback, follow-up, safety

import { useMemo, useEffect, useState, useRef, useCallback } from 'react';
import {
  Animated,
  Dimensions,
  LayoutAnimation,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  UIManager,
  View,
} from 'react-native';
import { router, useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar }      from 'expo-status-bar';
import { SafeAreaView }   from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics       from 'expo-haptics';
import * as Speech        from 'expo-speech';
import * as Clipboard     from 'expo-clipboard';
import { ScriptCard }     from '../src/components/ui/ScriptCard';
import { useAuth }        from '../src/context/AuthContext';
import { useChildProfile } from '../src/context/ChildProfileContext';
import { CrisisDetectedError } from '../src/lib/api';
import { supabase }       from '../src/lib/supabase';
import { saveScript }     from '../src/lib/saveScript';
import { detectCrisis } from '../src/hooks/useCrisisMode';
import { shouldShowProfileNudge, markNudgeShown } from '../src/utils/profileNudge';
import { useSubscription } from '../src/hooks/useSubscription';
import { PaywallSheet } from '../src/components/ui/PaywallSheet';
import { colors as C, fonts as F } from '../src/theme';

const { width: W } = Dimensions.get('window');

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const FALLBACKS = [
  { situation_summary: 'A hard moment is happening right now.',
    regulate: { parent_action: 'Take one breath. Move closer.', script: "You're really upset right now.", coaching: '', strategies: [] as string[] },
    connect:  { parent_action: 'Stay calm. Hold the limit.', script: "I can see this is hard. I'm here.", coaching: '', strategies: [] as string[] },
    guide:    { parent_action: 'Give one clear option.', script: "Let's take one step at a time.", coaching: '', strategies: [] as string[] },
    avoid: ["Stop this right now", "Calm down", "You're fine"] },
  { situation_summary: 'Your child is struggling right now.',
    regulate: { parent_action: 'Lower your voice. Get low.', script: 'That was really hard.', coaching: '', strategies: [] as string[] },
    connect:  { parent_action: "Stay close. Don't rush.", script: "I hear you. I'm not going anywhere.", coaching: '', strategies: [] as string[] },
    guide:    { parent_action: 'One step. Keep it simple.', script: "We'll figure this out together.", coaching: '', strategies: [] as string[] },
    avoid: ['Why would you do that?', 'You always do this', 'Just stop'] },
];

function isValid(v: unknown): boolean { return typeof v === 'string' && (v as string).trim().length > 4; }
type Params = { situationSummary?: string; regulateAction?: string; regulateScript?: string; regulateCoaching?: string; regulateStrategies?: string; connectAction?: string; connectScript?: string; connectCoaching?: string; connectStrategies?: string; guideAction?: string; guideScript?: string; guideCoaching?: string; guideStrategies?: string; avoid?: string; childMessage?: string; mode?: string; conversation_id?: string; childId?: string };const val = (v?: string | string[]) => Array.isArray(v) ? v[0] : v;
function parseStrategies(raw?: string): string[] { if (!raw) return []; try { const p = JSON.parse(raw); return Array.isArray(p) ? p : []; } catch { return []; } }

// ─── Voice Player ───
type VoiceState = 'idle' | 'playing';
type VoiceStep = 'regulate' | 'connect' | 'guide' | null;

function useVoicePlayer(script: { regulate: { parent_action: string; script: string }; connect: { parent_action: string; script: string }; guide: { parent_action: string; script: string }; }) {
  const [state, setState] = useState<VoiceState>('idle');
  const [currentStep, setCurrentStep] = useState<VoiceStep>(null);
  const mountedRef = useRef(true);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const queueRef = useRef<{ step: VoiceStep; text: string }[]>([]);
  const queueIdxRef = useRef(0);

  useEffect(() => { return () => { mountedRef.current = false; Speech.stop(); if (timeoutRef.current) clearTimeout(timeoutRef.current); }; }, []);

  const buildQueue = useCallback(() => [
    { step: 'regulate' as VoiceStep, text: `Regulate. ... ${script.regulate.parent_action} ... ${script.regulate.script}` },
    { step: 'connect' as VoiceStep,  text: `Connect. ... ${script.connect.parent_action} ... ${script.connect.script}` },
    { step: 'guide' as VoiceStep,    text: `Guide. ... ${script.guide.parent_action} ... ${script.guide.script}` },
  ], [script]);

  const speakNext = useCallback(() => {
    if (!mountedRef.current) return;
    const idx = queueIdxRef.current;
    if (idx >= queueRef.current.length) { setState('idle'); setCurrentStep(null); queueIdxRef.current = 0; return; }
    const item = queueRef.current[idx];
    setCurrentStep(item.step);
    Speech.speak(item.text, {
      language: 'en', rate: 0.85, pitch: 1.0,
      onDone: () => { if (!mountedRef.current) return; queueIdxRef.current = idx + 1; timeoutRef.current = setTimeout(() => { if (mountedRef.current) speakNext(); }, 1200); },
      onError: () => { if (!mountedRef.current) return; setState('idle'); setCurrentStep(null); },
    });
  }, []);

  const play = useCallback(() => { queueRef.current = buildQueue(); queueIdxRef.current = 0; setState('playing'); speakNext(); }, [buildQueue, speakNext]);
  const stop = useCallback(() => { Speech.stop(); if (timeoutRef.current) clearTimeout(timeoutRef.current); setState('idle'); setCurrentStep(null); queueIdxRef.current = 0; }, []);
  const toggle = useCallback(() => { if (state === 'playing') stop(); else play(); }, [state, play, stop]);
  return { state, currentStep, toggle, stop };
}

function PulsingDot() {
  const anim = useRef(new Animated.Value(0.4)).current;
  useEffect(() => { Animated.loop(Animated.sequence([
    Animated.timing(anim, { toValue: 1, duration: 600, useNativeDriver: true }),
    Animated.timing(anim, { toValue: 0.4, duration: 600, useNativeDriver: true }),
  ])).start(); }, [anim]);
  return <Animated.View style={[{ width: 6, height: 6, borderRadius: 3, backgroundColor: C.sos }, { opacity: anim }]} />;
}

// ═══════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════

export default function ResultScreen() {
  const navigation = useRouter();
  const params = useLocalSearchParams<Params>();
  const { session } = useAuth();
  const { activeChild } = useChildProfile();

  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveErr, setSaveErr] = useState('');
  const [avoidOpen, setAvoidOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [feedbackGiven, setFeedbackGiven] = useState(false);
  const [feedbackStep, setFeedbackStep] = useState<'helpful' | 'outcome' | 'done'>('helpful');
  const [feedbackHelpful, setFeedbackHelpful] = useState<string | null>(null);

  // Profile nudge — Master Blueprint: shown once per child after the
  // 3rd script. Gate via AsyncStorage so the parent sees it at exactly
  // the moment the personalisation feels real, never again.
  const [showNudge, setShowNudge] = useState(false);
  const nudgeOpacity = useRef(new Animated.Value(0)).current;

  // Voice playback gating — SOS is free for everyone; other modes
  // require Sturdy+. Free user tapping locked voice opens PaywallSheet.
  const { isPremium } = useSubscription();
  const [voicePaywall, setVoicePaywall] = useState(false);

  const isFallback = !isValid(val(params.regulateScript));
  const mode = val(params.mode) ?? 'sos';
  const coachingDefaultOpen = mode !== 'sos';
  const voiceLocked = mode !== 'sos' && !isPremium;
  const childName = activeChild?.name?.trim() ?? '';
  const childAge = activeChild?.childAge;
  const childInitial = childName ? childName[0].toUpperCase() : '?';
  const fallbackIndex = useMemo(() => Math.floor(Math.random() * FALLBACKS.length), [params.regulateScript]);
  const fallback = FALLBACKS[fallbackIndex];

  const script = {
    situation_summary: isValid(val(params.situationSummary)) ? val(params.situationSummary)! : fallback.situation_summary,
    regulate: isValid(val(params.regulateScript)) ? { parent_action: val(params.regulateAction) ?? '', script: val(params.regulateScript)!, coaching: val(params.regulateCoaching) ?? '', strategies: parseStrategies(val(params.regulateStrategies)) } : fallback.regulate,
    connect: isValid(val(params.connectScript)) ? { parent_action: val(params.connectAction) ?? '', script: val(params.connectScript)!, coaching: val(params.connectCoaching) ?? '', strategies: parseStrategies(val(params.connectStrategies)) } : fallback.connect,
    guide: isValid(val(params.guideScript)) ? { parent_action: val(params.guideAction) ?? '', script: val(params.guideScript)!, coaching: val(params.guideCoaching) ?? '', strategies: parseStrategies(val(params.guideStrategies)) } : fallback.guide,
    avoid: (() => { try { const raw = val(params.avoid); if (!raw) return fallback.avoid; const p = JSON.parse(raw); return Array.isArray(p) ? p : fallback.avoid; } catch { return fallback.avoid; } })(),
  };

  useEffect(() => {
    const childMessage = val(params.childMessage);
    if (childMessage) {
      const crisisCheck = detectCrisis(childMessage);
      if (crisisCheck.isCrisis) logSafetyEvent(childMessage, crisisCheck.crisisType!, crisisCheck.riskLevel!);
    }
  }, [params.childMessage]);

  const scriptId = useMemo(() => `r-${Date.now()}`, [params.regulateScript]);
  const voice = useVoicePlayer(script);

  useEffect(() => {
    setSaved(false); setSaving(false); setSaveErr(''); setAvoidOpen(false);
    setCopied(false);
    setFeedbackGiven(false); setFeedbackStep('helpful'); setFeedbackHelpful(null);
    return () => { voice.stop(); };
  }, [params.regulateScript]);

  // ─── Profile-nudge gate ───
  // Check once per child / per script. If eligible, mark shown
  // immediately so the nudge never reappears for this child on a
  // subsequent script (even if the parent doesn't tap it). Then fade
  // in 1s after script renders so it doesn't compete.
  useEffect(() => {
    const cid = typeof params.childId === 'string' ? params.childId : null;
    if (!cid) return;
    let cancelled = false;
    nudgeOpacity.setValue(0);
    setShowNudge(false);

    shouldShowProfileNudge(cid).then((should) => {
      if (cancelled || !should) return;
      setShowNudge(true);
      markNudgeShown(cid).catch(() => { /* no-op */ });
      const t = setTimeout(() => {
        Animated.timing(nudgeOpacity, {
          toValue: 1,
          duration: 600,
          useNativeDriver: true,
        }).start();
      }, 1000);
      // store the timer in a closure so cancel can clear it
      cancelTimer = () => clearTimeout(t);
    });

    let cancelTimer: (() => void) | null = null;
    return () => { cancelled = true; if (cancelTimer) cancelTimer(); };
  }, [params.childId, params.regulateScript]);

  const logSafetyEvent = async (excerpt: string, crisisType: string, riskLevel: string) => {
    if (!session?.user?.id) return;
    try { await supabase.from('safety_events').insert({ user_id: session.user.id, child_profile_id: activeChild?.id || null, conversation_id: val(params.conversation_id) || null, message_excerpt: excerpt.slice(0, 120), risk_level: riskLevel, policy_route: 'safety_support', classifier_version: 'v1-keyword', resolved_with: crisisType }); } catch {}
  };

  const handleGetHelp = () => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); logSafetyEvent('User tapped safety link', 'manual', 'ELEVATED_RISK'); router.push({ pathname: '/crisis', params: { crisisType: 'manual', riskLevel: 'ELEVATED_RISK' } }); };
  const handleCopy = () => { const text = [`Regulate: ${script.regulate.script}`, `Connect: ${script.connect.script}`, `Guide: ${script.guide.script}`].join('\n\n'); Clipboard.setStringAsync(text); setCopied(true); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); setTimeout(() => setCopied(false), 2000); };
const handleRetry = () => {
  voice.stop();
  const cid = typeof params.childId === 'string' ? params.childId : null;
  if (cid) navigation.push(`/child/${cid}` as any);
  else router.replace('/(tabs)');
};  const handleSave = async () => { if (saved || saving) return; setSaving(true); setSaveErr(''); try { await saveScript({ situation_summary: script.situation_summary, regulate: script.regulate, connect: script.connect, guide: script.guide, avoid: script.avoid, childProfileId: activeChild?.id, conversationId: val(params.conversation_id), triggerLabel: null }); setSaved(true); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); } catch { setSaveErr('Could not save.'); } finally { setSaving(false); } };
  const handleShare = async () => { const text = [`Regulate: ${script.regulate.script}`, `Connect: ${script.connect.script}`, `Guide: ${script.guide.script}`, '', '— Generated by Sturdy'].join('\n\n'); try { await Share.share({ message: text }); } catch {} };

  const handleFeedbackHelpful = async (value: string) => { setFeedbackHelpful(value); Haptics.selectionAsync(); if (value === 'yes') { await saveFeedback(value, null); setFeedbackGiven(true); } else { setFeedbackStep('outcome'); } };
  const handleFeedbackOutcome = async (outcome: string) => { Haptics.selectionAsync(); await saveFeedback(feedbackHelpful!, outcome); setFeedbackGiven(true); };
  const saveFeedback = async (helpful: string, outcome: string | null) => { if (!session?.user?.id) return; try { await supabase.from('script_feedback').insert({ user_id: session.user.id, child_profile_id: activeChild?.id || null, conversation_id: val(params.conversation_id) || null, helpful, outcome, most_helpful_step: null, parent_notes: null }); } catch {} };
  const toggleAvoid = () => { LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut); setAvoidOpen(prev => !prev); };

  const isPlaying = voice.state === 'playing';
  const showEscalationHelp = feedbackGiven && feedbackHelpful === 'no';

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <LinearGradient
        colors={[
          C.gradientResultTop,
          C.gradientResultMid1,
          C.gradientResultMid2,
          C.gradientResultMid3,
          C.gradientMid4,
          C.gradientBottom,
        ]}
        locations={[0, 0.10, 0.25, 0.42, 0.58, 1]}
        style={StyleSheet.absoluteFill}
      />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        {/* Back */}
        <View style={s.backRow}>
          <Pressable onPress={() => { voice.stop(); const cid = typeof params.childId === 'string' ? params.childId : null; if (cid) router.replace(`/child/${cid}` as any); else router.back(); }} style={s.back}><Text style={s.backText}>← Back</Text></Pressable>
          <Pressable onPress={() => { voice.stop(); router.replace('/(tabs)'); }} style={s.homeBtn}><Text style={s.homeBtnText}>🏠</Text></Pressable>
        </View>

        {/* Fallback */}
        {isFallback ? (
          <View style={s.fallbackCard}>
            <Text style={{ fontSize: 18 }}>🌿</Text>
            <View style={{ flex: 1, gap: 3 }}><Text style={s.fallbackTitle}>Couldn't connect right now</Text><Text style={s.fallbackBody}>Here's a general script to start with.</Text></View>
          </View>
        ) : null}

        {/* Header */}
        <View>
          <Text style={s.summary}>{script.situation_summary}</Text>
          <View style={s.tagRow}>
            <View style={s.ava}><Text style={s.avaText}>{childInitial}</Text></View>
            <Text style={s.tagText}>{childName || 'Your child'}{childAge ? `, age ${childAge}` : ''}</Text>
          </View>
        </View>

        {/* Safety */}
        <Pressable onPress={handleGetHelp} style={s.safetyLink}>
          <Text style={s.safetyIcon}>·</Text>
          <Text style={s.safetyText}>If this feels unsafe, <Text style={s.safetyLinkText}>get immediate help →</Text></Text>
        </Pressable>

        {/* Voice — SOS free; other modes Sturdy+ */}
        <Pressable onPress={() => voiceLocked ? setVoicePaywall(true) : voice.toggle()}>
          <View style={s.voiceCard}>
            <View style={[s.playBtn, isPlaying && s.playBtnActive, voiceLocked && s.playBtnLocked]}>
              <Text style={{ color: '#FFF', fontSize: 14, marginLeft: isPlaying ? 0 : 2 }}>
                {voiceLocked ? '🔒' : isPlaying ? '⏹' : '▶'}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Text style={s.voiceTitle}>
                  {voiceLocked
                    ? 'Listen to this script'
                    : isPlaying ? 'Playing script…' : 'Listen to this script'}
                </Text>
                {isPlaying && <PulsingDot />}
                {voiceLocked ? <Text style={s.voicePremiumPill}>Sturdy+</Text> : null}
              </View>
              <Text style={s.voiceSub}>
                {voiceLocked
                  ? 'Voice playback is part of Sturdy+ for non-SOS modes.'
                  : isPlaying
                    ? `Now: ${voice.currentStep === 'regulate' ? 'Regulate' : voice.currentStep === 'connect' ? 'Connect' : 'Guide'}`
                    : 'Put in your earbuds — Sturdy walks you through it'}
              </Text>
            </View>
          </View>
        </Pressable>

        {/* Avoid */}
        <Pressable onPress={toggleAvoid} style={s.avoidHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}><Text style={{ fontSize: 14 }}>⚠️</Text><Text style={s.avoidLabel}>AVOID SAYING</Text></View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}><Text style={s.avoidCount}>{script.avoid.length} phrases</Text><Text style={{ fontSize: 10, color: C.textMuted }}>{avoidOpen ? '▲' : '▼'}</Text></View>
        </Pressable>
        {avoidOpen ? (<View style={s.avoidBody}>{script.avoid.map((phrase, i) => (<View key={i} style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 8 }}><Text style={s.avoidX}>✕</Text><Text style={s.avoidText}>{phrase}</Text></View>))}</View>) : null}

        {/* Script cards */}
        <ScriptCard key={`r-${scriptId}`} step="Regulate" parent_action={script.regulate.parent_action} script={script.regulate.script} coaching={script.regulate.coaching} strategies={script.regulate.strategies} delay={0} defaultOpen={true} coachingOpen={coachingDefaultOpen} />
        <ScriptCard key={`c-${scriptId}`} step="Connect" parent_action={script.connect.parent_action} script={script.connect.script} coaching={script.connect.coaching} strategies={script.connect.strategies} delay={150} defaultOpen={false} coachingOpen={coachingDefaultOpen} />
        <ScriptCard key={`g-${scriptId}`} step="Guide" parent_action={script.guide.parent_action} script={script.guide.script} coaching={script.guide.coaching} strategies={script.guide.strategies} delay={300} defaultOpen={false} coachingOpen={coachingDefaultOpen} />

        {/* Feedback */}
        {!feedbackGiven ? (
          <View style={s.feedbackCard}>
            {feedbackStep === 'helpful' ? (<><Text style={s.feedbackQuestion}>Did this help?</Text><View style={s.feedbackRow}>{[{ value: 'yes', label: '👍 Yes' }, { value: 'somewhat', label: '🤷 Somewhat' }, { value: 'no', label: '👎 No' }].map(opt => (<Pressable key={opt.value} onPress={() => handleFeedbackHelpful(opt.value)} style={({ pressed }) => [s.feedbackChip, pressed && { opacity: 0.7 }]}><Text style={s.feedbackChipText}>{opt.label}</Text></Pressable>))}</View></>) : feedbackStep === 'outcome' ? (<><Text style={s.feedbackQuestion}>What happened?</Text><View style={s.feedbackRow}>{[{ value: 'calmed', label: '😌 Calmed down' }, { value: 'escalated', label: '📈 Escalated' }, { value: 'ignored', label: '😶 Ignored' }, { value: 'ongoing', label: '⏳ Still going' }].map(opt => (<Pressable key={opt.value} onPress={() => handleFeedbackOutcome(opt.value)} style={({ pressed }) => [s.feedbackChip, pressed && { opacity: 0.7 }]}><Text style={s.feedbackChipText}>{opt.label}</Text></Pressable>))}</View></>) : null}
          </View>
        ) : (<View style={s.feedbackThanks}><Text style={s.feedbackThanksText}>Thanks — this helps Sturdy learn ✓</Text></View>)}

        {/* Escalation */}
        {showEscalationHelp ? (
          <View style={s.escalationCard}>
            <Text style={s.escalationTitle}>We hear you.</Text>
            <Text style={s.escalationBody}>Some moments need more than a script. If this situation is getting worse or feels unsafe, you don't have to handle it alone.</Text>
            <Pressable onPress={handleGetHelp} style={s.escalationBtn}><Text style={s.escalationBtnText}>Talk to someone now →</Text></Pressable>
          </View>
        ) : null}

        {/* Nudge — gated to once-per-child after 3+ scripts; routes to the
            Your Child profile screen (the spec'd conversion trigger). */}
        {showNudge ? (
          <Animated.View style={[s.nudgeCard, { opacity: nudgeOpacity }]}>
            <Text style={s.nudgeText}>
              Sturdy is learning how{' '}
              <Text style={s.nudgeName}>{childName || 'your child'}</Text>
              {' '}responds.
            </Text>
            <Pressable
              onPress={() => {
                const cid = typeof params.childId === 'string' ? params.childId : null;
                if (cid) router.push(`/child-profile/${cid}` as any);
                else router.replace('/(tabs)');
              }}
              hitSlop={8}
            >
              <Text style={s.nudgeLink}>
                See {childName ? `${childName}'s` : 'their'} profile →
              </Text>
            </Pressable>
          </Animated.View>
        ) : null}
        <Pressable onPress={handleShare} style={{ alignSelf: 'center', paddingVertical: 8 }}><Text style={s.shareText}>Share script</Text></Pressable>
        {saveErr ? <Text style={s.errorText}>{saveErr}</Text> : null}
        <View style={{ height: 100 }} />
      </ScrollView>

      <PaywallSheet
        visible={voicePaywall}
        onClose={() => setVoicePaywall(false)}
        feature="Voice playback"
        body="Sturdy reads the script aloud for Reconnect, Understand, and Conversation modes when you're on Sturdy+. SOS voice is always free."
      />

      {/* Footer */}
      <View style={s.footer}>
        <LinearGradient
          colors={['transparent', 'rgba(12,12,12,0.85)', C.background]}
          locations={[0, 0.35, 0.75]}
          style={s.footerFade}
          pointerEvents="none"
        />
        <View style={s.footerContent}>
          <View style={s.footerRow}>
            <Pressable onPress={handleSave} disabled={saved || saving} style={({ pressed }) => [s.footerGhost, pressed && { opacity: 0.7 }]}>
              <Text style={s.footerGhostText}>{saved ? '✓ Saved' : saving ? 'Saving…' : 'Save'}</Text>
            </Pressable>
            <Pressable onPress={handleCopy} style={({ pressed }) => [s.footerGhost, pressed && { opacity: 0.7 }]}>
              <Text style={s.footerGhostText}>{copied ? '✓ Copied' : 'Copy'}</Text>
            </Pressable>
            <Pressable onPress={handleRetry} style={({ pressed }) => [pressed && { opacity: 0.9, transform: [{ scale: 0.98 }] }]}>
              <View style={s.footerPrimary}><Text style={s.footerPrimaryText}>Retry</Text></View>
            </Pressable>
          </View>
        </View>
      </View>
      </SafeAreaView>
    </View>
  );
}

const card = {
  backgroundColor: C.surface,
  borderWidth:     1,
  borderColor:     C.border,
  borderTopWidth:  1,
  borderTopColor:  C.borderHi,
  borderRadius:    18,
  shadowColor:     '#000000',
  shadowOffset:    { width: 0, height: 6 },
  shadowOpacity:   0.35,
  shadowRadius:    20,
  elevation:       4,
} as const;

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.background },
  scroll: { paddingHorizontal: 24, paddingTop: 8, paddingBottom: 40, gap: 14 },

  backRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  back: { alignSelf: 'flex-start', paddingVertical: 6 },
  backText: { fontFamily: F.bodyMedium, fontSize: 15, color: C.textSecondary },
  homeBtn: { paddingVertical: 6, paddingHorizontal: 10 },
  homeBtnText: { fontSize: 20 },

  fallbackCard: { ...card, flexDirection: 'row', alignItems: 'flex-start', gap: 10, padding: 14 },
  fallbackTitle: { fontFamily: F.bodySemi, fontSize: 14, color: C.sage },
  fallbackBody: { fontFamily: F.body, fontSize: 13, color: C.textSecondary },

  summary: { fontFamily: F.scriptItalic, fontSize: 21, color: C.text, lineHeight: 30, marginBottom: 8 },
  tagRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  ava: { width: 22, height: 22, borderRadius: 11, backgroundColor: C.sage, alignItems: 'center', justifyContent: 'center' },
  avaText: { fontFamily: F.bodySemi, fontSize: 10, color: '#FFFFFF' },
  tagText: { fontFamily: F.body, fontSize: 12, color: C.textSecondary },

  safetyLink: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 2 },
  safetyIcon: { color: C.sos, fontSize: 16 },
  safetyText: { fontFamily: F.body, fontSize: 12, color: C.textSecondary },
  safetyLinkText: { fontFamily: F.bodySemi, color: C.sos, textDecorationLine: 'underline' },

  voiceCard: { ...card, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  playBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: C.sage, alignItems: 'center', justifyContent: 'center' },
  playBtnActive: { backgroundColor: C.sos },
  playBtnLocked: { backgroundColor: C.amberMuted },
  voicePremiumPill: {
    fontFamily: F.label, fontSize: 9, letterSpacing: 0.8,
    color: C.amber, backgroundColor: C.amberBadge,
    paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: 999, overflow: 'hidden', marginLeft: 4,
  },
  voiceTitle: { fontFamily: F.bodySemi, fontSize: 14, color: C.text },
  voiceSub: { fontFamily: F.body, fontSize: 12, color: C.textSecondary, marginTop: 2 },

  avoidHeader: { ...card, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14 },
  avoidLabel: { fontFamily: F.bodySemi, fontSize: 12, letterSpacing: 0.6, color: C.sos },
  avoidCount: { fontFamily: F.bodyMedium, fontSize: 11, color: C.textMuted, backgroundColor: C.chipBg, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10 },
  avoidBody: { paddingHorizontal: 18, paddingBottom: 14, gap: 8, marginTop: -8 },
  avoidX: { fontFamily: F.bodySemi, fontSize: 10, color: C.sos, marginTop: 3 },
  avoidText: { fontFamily: F.script, fontSize: 14, color: C.textSecondary, lineHeight: 21, flex: 1 },

  feedbackCard: { ...card, alignItems: 'center', gap: 12, padding: 18 },
  feedbackQuestion: { fontFamily: F.bodySemi, fontSize: 15, color: C.text },
  feedbackRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
  feedbackChip: { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 14, backgroundColor: C.chipBg, borderWidth: 1, borderColor: C.chipBorder },
  feedbackChipText: { fontFamily: F.bodyMedium, fontSize: 13, color: C.text },
  feedbackThanks: { alignItems: 'center', paddingVertical: 12 },
  feedbackThanksText: { fontFamily: F.bodyMedium, fontSize: 13, color: C.sage },

  escalationCard: { ...card, padding: 18, gap: 10, backgroundColor: C.sosLight, borderColor: 'rgba(232,116,97,0.20)' },
  escalationTitle: { fontFamily: F.heading, fontSize: 18, color: C.sos },
  escalationBody: { fontFamily: F.body, fontSize: 14, color: C.text, lineHeight: 22 },
  escalationBtn: { alignSelf: 'flex-start', paddingVertical: 10, paddingHorizontal: 16, borderRadius: 12, backgroundColor: C.sosBadge, borderWidth: 1, borderColor: 'rgba(232,116,97,0.30)' },
  escalationBtnText: { fontFamily: F.bodySemi, fontSize: 14, color: C.sos },

  nudgeCard: { ...card, alignSelf: 'center', maxWidth: 360, alignItems: 'center', gap: 6, paddingVertical: 14, paddingHorizontal: 18, backgroundColor: C.sageLight, borderColor: 'rgba(138,160,96,0.20)' },
  nudgeText: { fontFamily: F.body, fontSize: 13, color: C.textSecondary, textAlign: 'center' },
  nudgeName: { fontFamily: F.headingItalic, fontSize: 14, color: C.text },
  nudgeLink: { fontFamily: F.bodySemi, fontSize: 13, color: C.sage },

  shareText: { fontFamily: F.bodySemi, fontSize: 13, color: C.amberLight, textDecorationLine: 'underline' },
  errorText: { fontFamily: F.body, fontSize: 13, color: C.sos, textAlign: 'center' },

  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 10 },
  footerFade: { height: 40 },
  footerContent: { backgroundColor: C.background, paddingHorizontal: 24, paddingBottom: 28, paddingTop: 4 },
  footerRow: { flexDirection: 'row', gap: 10 },
  footerGhost: { flex: 1, borderRadius: 16, minHeight: 50, alignItems: 'center', justifyContent: 'center', backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderTopWidth: 1, borderTopColor: C.borderHi },
  footerGhostText: { fontFamily: F.bodyMedium, fontSize: 14, color: C.text },
  footerPrimary: { flex: 1, borderRadius: 16, minHeight: 50, minWidth: 100, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 20, backgroundColor: C.sos },
  footerPrimaryText: { fontFamily: F.subheading, fontSize: 14, color: '#FFFFFF', letterSpacing: 0.3 },
});


